//
//  antlrcpp-ios.h
//  antlrcpp-ios
//
//  Created by Mike Lischke on 05.05.16.
//  Copyright © 2016 Mike Lischke. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for antlrcpp-ios.
FOUNDATION_EXPORT double antlrcpp_iosVersionNumber;

//! Project version string for antlrcpp-ios.
FOUNDATION_EXPORT const unsigned char antlrcpp_iosVersionString[];

#include "antlr4-runtime.h"
